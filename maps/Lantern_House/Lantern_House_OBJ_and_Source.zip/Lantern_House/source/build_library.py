import bpy,math,random,json,os,time
from pathlib import Path
from mathutils import Vector,Matrix
ROOT=Path('/workspace/work/library'); TEX=ROOT/'assets/textures'; MOD=ROOT/'assets/models'; random.seed(20261024)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for db in bpy.data.materials: bpy.data.materials.remove(db)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=96;scene.cycles.use_denoising=False
scene.render.threads_mode='FIXED';scene.render.threads=8
scene.render.resolution_x=1600;scene.render.resolution_y=1100;scene.render.resolution_percentage=100
scene.world.color=(.17,.20,.24)
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast'
scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
S=50.0
statics=[];colliders=[];recepts=[];lights=[];loose=[];catalog=json.loads((ROOT/'book_catalogue.json').read_text());used=set(range(384))
C=Matrix(((1,0,0),(0,0,1),(0,-1,0)))
def mat(name,color,tex=None,metal=0,rough=.5,emit=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
 if emit:p.inputs['Emission Color'].default_value=(*color,1);p.inputs['Emission Strength'].default_value=emit
 if tex:
  t=m.node_tree.nodes.new('ShaderNodeTexImage');t.image=bpy.data.images.load(str(TEX/tex),check_existing=True);m.node_tree.links.new(t.outputs['Color'],p.inputs['Base Color'])
 return m
wood=mat('Carved_walnut',(.3,.18,.095),'walnut.png');oak=mat('Warm_oak',(.4,.26,.15),'oak.png');floor_mat=mat('Oiled_parquet',(.35,.22,.13),'floor.png',rough=.38)
brass=mat('Antique_brass',(.55,.37,.12),metal=.72,rough=.28);black=mat('Iron',(.025,.033,.03),metal=.6)
green=mat('Bottle_green_leather',(.035,.10,.075),rough=.65);plaster=mat('Warm_plaster',(.52,.45,.33),rough=.9);dark=mat('Deep_sage_paint',(.075,.13,.115));cream=mat('Ivory',(.72,.65,.47));glass=mat('Frosted_amber',(.9,.64,.28),emit=.8);sky=mat('Moonlit_window',(.26,.40,.52),emit=.45)
collection=mat('Unique_collection_covers',(1,1,1),'collection_atlas.png',rough=.7)
# Every static cube can contribute a precise, separate Fio brush collider.
def collider(o):
 corners=[o.matrix_world@Vector(v) for v in o.bound_box]; mn=[min(v[j] for v in corners) for j in range(3)];mx=[max(v[j] for v in corners) for j in range(3)]
 colliders.append({'pos':[(mn[j]+mx[j])/2 for j in range(3)],'size':[mx[j]-mn[j] for j in range(3)],'name':o.name})
def box(name,loc,size,material=wood,bevel=.015,solid=False,rot=0):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=size;o.rotation_euler[2]=rot;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 o.data.materials.append(material)
 if bevel:
  m=o.modifiers.new('Soft_edges','BEVEL');m.width=bevel;m.segments=2
  m=o.modifiers.new('Weighted_normals','WEIGHTED_NORMAL')
 statics.append(o)
 if solid:
  bpy.context.view_layer.update();collider(o)
 return o

def cyl(name,loc,radius,depth,material=brass,verts=16,axis='Z',rot=0):
 bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=radius,depth=depth,location=loc);o=bpy.context.object;o.name=name
 if axis=='Y':o.rotation_euler[0]=math.pi/2
 if axis=='X':o.rotation_euler[1]=math.pi/2
 o.rotation_euler[2]+=rot;o.data.materials.append(material);statics.append(o);return o

def sphere(name,loc,scale,material=brass):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,radius=1,location=loc);o=bpy.context.object;o.name=name;o.scale=scale;o.data.materials.append(material);statics.append(o);return o

def plaque(i,loc,width,height,rot=0):
 # A thin cube's front faces receive the printed plaque texture.
 pm=mat('Plaque_%02d'%i,(1,1,1),f'plaque_{i:02d}.png')
 o=box('Enamel_sign_'+str(i),loc,(width,.025,height),pm,.003,rot=rot)
 # cube defaults UV are atlas-cross; replace with full face UVs
 uv=o.data.uv_layers.active.data
 for p in o.data.polygons:
  for li in p.loop_indices:
   v=o.data.vertices[o.data.loops[li].vertex_index].co
   uv[li].uv=(v.x/width+.5,v.z/height+.5)
 return o
# Architectural shell.
box('Foundation',(0,0,-.18),(19.8,23,.36),wood,.02,True)
# Individually laid staggered oak parquet planks.
for row in range(38):
 y=-11.2+(row+.5)*22.4/38
 for col in range(13):
  x=-9.6+(col+.5)*1.6+(row%2)*.8
  left=max(-9.6,x-.798);right=min(9.6,x+.798)
  if right>left:box('Parquet_%02d_%02d'%(row,col),((left+right)/2,y,-.022),(right-left,.583,.045),floor_mat,.002)
box('North_wall',(0,11.35,3.2),(19.8,.30,6.4),plaster,.015,True)
box('South_wall',(0,-11.35,3.2),(19.8,.3,6.4),dark,.015,True)
for x in [-9.75,9.75]:box('Side_wall',(x,0,3.2),(.3,22.4,6.4),plaster,.015,True)
box('Ceiling',(0,0,6.55),(19.8,23,.3),dark,.02,True)
# Coffered ceiling and matching wall dado rails.
for x in [-9.45,-6.3,-3.15,0,3.15,6.3,9.45]:
 box('Coffer_beam',(x,0,6.23),(.18,22.4,.28),wood,.02)
 for y in [-11,-5.5,0,5.5,11]:box('Coffer_rosette',(x,y,6.04),(.3,.3,.08),brass,.02)
for y in [-11,-5.5,0,5.5,11]:box('Transverse_beam',(0,y,6.23),(19.2,.2,.28),wood,.02)
for z in [.13,1.12,5.96,6.10]:
 for x in [-9.55,9.55]:box('Side_moulding',(x,0,z),(.13,22.4,.12),wood,.012)
 for y in [-11.1,11.1]:box('End_moulding',(0,y,z),(19.2,.13,.12),wood,.012)
for x in [-8.4,-5.6,-2.8,2.8,5.6,8.4]:
 for y in [-11.14,11.14]:box('Wall_panel',(x,y,.6),(2.65,.07,.92),wood,.012)
# Windows across the entry wall with leaded panes, deep frames and curtains.
for x in [-6.6,6.6]:
 box('Window_recess',(x,-11.14,3.4),(3.7,.07,3.4),black,.01)
 for dx in [-1.24,0,1.24]:
  for dz in [-1.12,0,1.12]:box('Leaded_glass',(x+dx,-11.08,3.4+dz),(1.19,.035,1.07),sky,.005)
 for dx in [-1.88,-.62,.62,1.88]:box('Window_mullion',(x+dx,-11.01,3.4),(.08,.16,3.6),wood,.015)
 for dz in [-1.8,-.58,.58,1.8]:box('Window_transom',(x,-11.01,3.4+dz),(3.9,.17,.09),wood,.012)
 box('Window_sill',(x,-10.98,1.51),(4.0,.40,.12),oak,.02,True)
 for side in [-1,1]:
  for j in range(6):cyl('Velvet_curtain',(x+side*(1.98+j*.055),-10.93,3.4),.08,3.8,green,12)
 cyl('Curtain_rail',(x,-10.90,5.38),.035,4.8,brass,axis='X')
# Entry door, reception desk and mission notices.
box('Entry_door',(0,-11.1,1.7),(2.6,.18,3.4),wood,.02)
for x in [-1.36,1.36]:box('Door_jamb',(x,-10.94,1.8),(.13,.15,3.6),brass,.01)
box('Door_lintel',(0,-10.94,3.62),(2.85,.17,.15),oak,.02)
for x in [-.67,.67]:
 for z in [.8,2.4]:box('Raised_door_panel',(x,-10.98,z),(1.05,.1,1.25),oak,.02)
 cyl('Door_handle',(x*.45,-10.84,1.5),.035,.3,brass)
plaque(0,(0,-10.82,4.2),4.6,.86)
plaque(1,(0,11.08,5.93),6.8,.65)
plaque(10,(0,-11.06,5.52),5.8,.38)
# Book mesh: layered boards, inset leaf block and a rounded spine.
def make_book_mesh(name,material,atlas_index=None):
 verts=[];faces=[];uvs=[]
 def cub(vmin,vmax,region='pages'):
  x0,y0,z0=vmin;x1,y1,z1=vmax;b=len(verts)
  verts.extend([(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0),(x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)])
  for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:
   faces.append(tuple(b+i for i in ids))
   if region=='board' and ids in [(0,3,2,1),(4,5,6,7)]:r=(.005,.01,.675,.99)
   elif ids==(3,0,4,7):r=(.695,.01,.825,.99)
   elif region=='board':r=(.70,.88,.82,.96)
   else:r=(.86,.02,.995,.98)
   a,bv,c,d=r;coords=[(a,bv),(c,bv),(c,d),(a,d)]
   if ids==(4,5,6,7):coords=[(a,bv),(c,bv),(c,d),(a,d)]
   if atlas_index is not None:
    tx=atlas_index%32;ty=atlas_index//32
    coords=[((tx+u)/32,1-(ty+1-v)/32) for u,v in coords]
   uvs.append(coords)
 cub((-.22,-.32,-.04),(.22,.32,-.029),'board');cub((-.22,-.32,.029),(.22,.32,.04),'board')
 cub((-.213,-.306,-.029),(.207,.306,.029))
 cub((-.222,-.315,-.032),(-.207,.315,.032),'board')
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update();uv=mesh.uv_layers.new(name='Covers_spine_leaves')
 for p,coords in zip(mesh.polygons,uvs):
  for li,c in zip(p.loop_indices,coords):uv.data[li].uv=c
 mesh.materials.append(material);return mesh
base_mat=mat('Book_default',(1,1,1),'books/B0001.png',rough=.68);base=make_book_mesh('Book_master_mesh',base_mat)
# Mark all shelf books as individually titled collection volumes, each with a unique atlas tile.
next_static=384

def shelfbook(loc,rotZ=0):
 global next_static
 idx=next_static;next_static+=1;used.add(idx)
 mesh=make_book_mesh('Collection_'+catalog[idx]['id'],collection,idx-384);o=bpy.data.objects.new(catalog[idx]['title'],mesh);bpy.context.collection.objects.link(o);o.location=loc
 # stand on spine edge: original long axis becomes vertical
 o.rotation_euler=(math.pi/2,0,rotZ+math.pi/2);o.scale=(random.uniform(.86,1.04),random.uniform(.88,1.04),random.uniform(.7,1.2));statics.append(o)
 return o

def bookcase(cx,cy,angle=0,num=0):
 # Local +Y is the exposed side; back is -Y.
 ca,sa=math.cos(angle),math.sin(angle)
 def pt(x,y,z):return (cx+ca*x-sa*y,cy+sa*x+ca*y,z)
 def bx(name,loc,size,material=wood,bev=.012,solid=False):return box(name,pt(*loc),size,material,bev,solid,angle)
 w=2.84;depth=1.0
 for x in [-1.37,1.37]:
  bx('Fluted_case_pilaster', (x,0,2.81),(.1,depth,5.62),wood,.015,True)
  for dx in [-.022,.022]:bx('Pilaster_flute',(x+dx,.515,2.84),(.014,.012,5.1),brass,.003)
  bx('Pilaster_base',(x,.03,.16),(.18,1.1,.24),oak,.02)
  bx('Pilaster_capital',(x,.03,5.44),(.22,1.12,.16),brass,.02)
 bx('Case_back',(0,-.47,2.8),(2.64,.06,5.6),dark,.01,True)
 for j,z in enumerate([.17,1.21,2.25,3.29,4.33,5.37]):
  bx('Solid_shelf', (0,0,z),(2.68,.98,.09),oak,.015,True)
  bx('Shelf_brass_edge',(0,.501,z),(2.62,.025,.035),brass,.005)
  # The lower four tiers are empty return bays with slot spacing for books lying flat.
  if j<4:
   world=pt(0,0,z+.045+.35)
   # Function slots move only X for cols or Z for rows; support both wall orientations.
   if abs(sa)<.1:recepts.append({'pos':world,'capacity':3,'slot_cols':3,'slot_spacing':[.88,0,0],'slot_offset':[0,0,0],'name':f'Case_{num:02d}_shelf_{j+1}'})
   else:recepts.append({'pos':world,'capacity':3,'slot_cols':1,'slot_spacing':[0,0,.88],'slot_offset':[0,0,-.88],'name':f'Case_{num:02d}_shelf_{j+1}'})
  else:
   # titles face out on the visible spines, upper collection shelf
   for k in range(21):
    p=pt(-1.25+k*.122,.11,z+.045+.305)
    shelfbook(p,angle)
 bx('Case_crown',(0,0,5.65),(3.04,1.14,.17),wood,.025)
 bx('Crown_inlay',(0,.58,5.65),(2.91,.025,.04),brass,.003)
 # Small shelf markers on each lower rail.
 for j,z in enumerate([.17,1.21,2.25,3.29]):
  for xx in [-.88,0,.88]:bx('Return_slot_marker',(xx,.522,z+.005),(.15,.02,.045),brass,.004)
 return pt
# Six tall bays at the rear and six on each side = 18.
for i in range(6):bookcase(-7.5+i*3.0,10.58,math.pi,i+1)
for side in [-1,1]:
 for i in range(6):bookcase(side*9.02,-6.9+i*3.0,(-math.pi/2 if side<0 else math.pi/2),7+(0 if side<0 else 6)+i)
# Subject signs above rear cases.
for i in range(6):plaque(2+i%6,(-7.5+3*i,9.982,5.74),2.55,.28)
# Four low islands, double-sided, 24 slots per side = 192.
for isle,(cx,cy) in enumerate([(-4.15,-3.35),(4.15,-3.35),(-4.15,3.0),(4.15,3.0)]):
 box('Island_centre',(cx,cy,1.98),(5.46,.09,3.96),dark,.01,True)
 for x in [cx-2.75,cx+2.75]:box('Island_end',(x,cy,2.06),(.12,2.06,4.12),wood,.02,True)
 for z in [.17,1.21,2.25,3.29]:
  for side in [-1,1]:
   yy=cy+side*.52
   box('Island_shelf',(cx,yy,z),(5.44,.98,.09),oak,.015,True)
   box('Island_brass_rail',(cx,cy+side*1.025,z),(5.3,.028,.035),brass,.003)
   recepts.append({'pos':(cx,yy,z+.395),'capacity':6,'slot_cols':6,'slot_spacing':[.88,0,0],'slot_offset':[0,0,0],'name':f'Island_{isle+1}_{side}_{z}'})
 box('Island_crown',(cx,cy,4.16),(5.7,2.2,.16),wood,.02,True)
 for side in [-1,1]:
  # Each side's return instruction plate at reachable height.
  plaque(8,(cx,cy+side*1.11,3.64),2.8,.40)
 # Stacked display folios and brass bookends on the island top.
 for k in range(8):
  idx=next_static;next_static+=1;used.add(idx);mesh=make_book_mesh('Folio_'+str(idx),collection,idx-384)
  o=bpy.data.objects.new(catalog[idx]['title'],mesh);bpy.context.collection.objects.link(o);o.location=(cx-1.7+(k//4)*3.2,cy,4.30+(k%4)*.085);o.rotation_euler[2]=random.uniform(-.15,.15);statics.append(o)
# Green leather reading armchairs and walnut tables at front corners.
for side in [-1,1]:
 cx=side*6.4;cy=-8.7
 box('Chair_seat',(cx,cy,.72),(1.25,1.35,.22),green,.12,True)
 box('Chair_back',(cx,cy-.52,1.35),(1.3,.25,1.55),green,.10,True)
 for dx in [-.71,.71]:
  box('Chair_arm',(cx+dx,cy,1.1),(.19,1.45,.2),wood,.08,True)
  for dy in [-.47,.47]:cyl('Turned_chair_leg',(cx+dx*.78,cy+dy,.34),.06,.6,wood)
 for row in range(3):
  for col in range(4):sphere('Leather_button',(cx-.43+col*.28,cy-.37,1.04+row*.37),(.025,.018,.025),brass)
 tx=cx-side*1.5
 cyl('Side_table_top',(tx,cy,1.08),.53,.10,wood,32);cyl('Pedestal',(tx,cy,.59),.09,.95,wood);cyl('Table_foot',(tx,cy,.12),.36,.08,wood,24)
 box('Table_collider',(tx,cy,.65),(.95,.95,1.25),wood,0,True).hide_render=True
 # reading lamp with a warm glass shade
 cyl('Lamp_foot',(tx,cy,1.18),.18,.07,brass,24);cyl('Lamp_stem',(tx,cy,1.51),.025,.65,brass)
 sphere('Banker_lamp_shade',(tx,cy,1.87),(.38,.22,.18),green);sphere('Lamp_glow',(tx,cy,1.82),(.28,.13,.055),glass)
 # porcelain cup and saucer
 cyl('Saucer',(tx+.24,cy+.17,1.15),.105,.02,cream,24);cyl('Cup',(tx+.24,cy+.17,1.22),.068,.12,cream,24)
# Card catalogue cabinet under title and detailed drawers.
box('Catalogue_cabinet',(-2.35,-9.9,.96),(1.9,1.0,1.92),wood,.025,True)
for row in range(6):
 for col in range(4):
  x=-3.04+col*.46;z=.18+row*.29
  box('Index_drawer',(x,-9.382,z),(.43,.045,.255),oak,.005)
  box('Drawer_label',(x,-9.35,z+.035),(.20,.018,.075),brass,.005)
  cyl('Drawer_pull',(x,-9.32,z-.035),.018,.11,brass,axis='X')
plaque(9,(-2.35,-9.34,2.15),2.8,.36)
# Globe and open atlas on a reception writing table.
box('Reception_table',(2.9,-9.6,1.4),(3.7,1.25,.12),wood,.025,True)
for x in [1.25,4.55]:
 for y in [-10.1,-9.1]:cyl('Desk_leg',(x,y,.68),.075,1.35,wood)
sphere('Terrestrial_globe',(3.95,-9.6,1.91),(.37,.37,.37),green);cyl('Globe_stand',(3.95,-9.6,1.53),.15,.13,brass)
for j in range(6):
 bpy.ops.mesh.primitive_torus_add(major_segments=32,minor_segments=8,location=(3.95,-9.6,1.91),major_radius=.373,minor_radius=.008)
 o=bpy.context.object;o.name='Globe_meridian';o.rotation_euler=(math.pi/2,0,j*math.pi/6);o.data.materials.append(brass);statics.append(o)
# Rolling ladder on the rear wall, with eight rungs and brass wheels.
for x in [6.65,7.45]:
 o=box('Ladder_rail',(x,9.2,2.45),(.08,.11,4.9),oak,.02);o.rotation_euler[0]=-.13
for i in range(10):cyl('Ladder_rung',(7.05,9.2+(i*.44-2.2)*.13,.3+i*.44),.045,.86,brass,axis='X')
for x in [6.65,7.45]:cyl('Ladder_wheel',(x,8.9,.12),.12,.07,black,axis='Y')
cyl('Ladder_track',(0,9.88,5.58),.035,17.8,brass,axis='X')
# Two hanging octagonal brass chandeliers and four ambient lights.
for cy in [-5.5,4.8]:
 cyl('Pendant_chain',(0,cy,5.83),.022,.75,black)
 bpy.ops.mesh.primitive_torus_add(major_segments=48,minor_segments=8,location=(0,cy,5.36),major_radius=1.10,minor_radius=.035)
 o=bpy.context.object;o.name='Chandelier_brass_ring';o.data.materials.append(brass);statics.append(o)
 for j in range(8):
  a=j*math.pi/4;x=1.10*math.cos(a);y=cy+1.10*math.sin(a)
  cyl('Lantern_base',(x,y,5.20),.13,.04,brass)
  cyl('Lantern_glass',(x,y,5.38),.10,.32,glass,12)
  cyl('Lantern_cap',(x,y,5.56),.14,.05,brass)
 lights.append(((0,cy,5.0),(1.0,.76,.48),1700,3.0))
for loc in [(-6,-6,4.4),(6,-6,4.4),(-6,6,4.4),(6,6,4.4),(0,-9.8,4.2),(0,9.5,4.2)]:lights.append((loc,(1,.83,.62),1150,4.0))
for loc,col,power,size in lights:
 data=bpy.data.lights.new('Library_warm_light','AREA');data.energy=power;data.color=col;data.shape='DISK';data.size=size;o=bpy.data.objects.new(data.name,data);bpy.context.collection.objects.link(o);o.location=loc
# Let window light enter from the front.
for x in [-6.6,6.6]:
 data=bpy.data.lights.new('Window_fill','AREA');data.energy=1100;data.color=(.55,.70,1);data.shape='RECTANGLE';data.size=3;data.size_y=3
 o=bpy.data.objects.new(data.name,data);bpy.context.collection.objects.link(o);o.location=(x,-10.8,3.8);o.rotation_euler=(math.pi/2,0,0)
# Rigid-body setup uses clean cuboids matching the actual architecture.
for i,co in enumerate(colliders):
 bpy.ops.mesh.primitive_cube_add(size=1,location=co['pos']);o=bpy.context.object;o.name='PHYS_'+co['name'];o.dimensions=co['size'];bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 bpy.ops.rigidbody.object_add();o.rigid_body.type='PASSIVE';o.rigid_body.collision_shape='BOX';o.rigid_body.friction=.68;o.rigid_body.use_margin=True;o.rigid_body.collision_margin=.001;o.hide_render=True
# Spawn loose books high above all accessible floor regions. Keep the arrival apron clear.
initial=[]
def free(x,y):
 if abs(x)>8.1 or y>9.0 or y< -9.4:return False
 if abs(x)<1.8 and y< -7.9:return False
 if abs(x)>4.6 and y< -7.7:return False
 if (x+2.35)**2+(y+9.9)**2<2.0:return False
 for cx,cy in [(-4.15,-3.35),(4.15,-3.35),(-4.15,3.0),(4.15,3.0)]:
  if abs(x-cx)<3.12 and abs(y-cy)<1.45:return False
 return True
for i in range(384):
 info=catalog[i];bm=mat('Cover_'+info['id'],(1,1,1),'books/'+info['id']+'.png',rough=.67)
 o=bpy.data.objects.new(info['id']+'__'+info['title'],base.copy());o.data.materials.clear();o.data.materials.append(bm);bpy.context.collection.objects.link(o)
 while True:
  x=random.uniform(-8.1,8.1);y=random.uniform(-9.35,8.9);z=random.uniform(4.75,5.90)
  if free(x,y) and all((x-a[0])**2+(y-a[1])**2+(z-a[2])**2>.45**2 for a in initial):break
 o.location=(x,y,z);o.rotation_euler=(random.uniform(-math.pi,math.pi),random.uniform(-math.pi,math.pi),random.uniform(-math.pi,math.pi));o.scale=(random.uniform(.83,1.16),random.uniform(.84,1.12),random.uniform(.7,1.5));initial.append((x,y,z))
 bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.rigidbody.object_add();o.rigid_body.collision_shape='CONVEX_HULL';o.rigid_body.mass=.5+o.scale.z*.35;o.rigid_body.friction=.66;o.rigid_body.restitution=.075;o.rigid_body.linear_damping=.36;o.rigid_body.angular_damping=.48;o.rigid_body.use_deactivation=True;o.rigid_body.use_start_deactivated=False;o.rigid_body.deactivate_linear_velocity=.10;o.rigid_body.deactivate_angular_velocity=.12;o.rigid_body.use_margin=True;o.rigid_body.collision_margin=.0015;o.select_set(False);loose.append(o)
scene.gravity=(0,0,-9.81);scene.render.fps=24;scene.frame_start=1;scene.frame_end=1441;scene.rigidbody_world.substeps_per_frame=8;scene.rigidbody_world.solver_iterations=35;scene.rigidbody_world.point_cache.frame_start=1;scene.rigidbody_world.point_cache.frame_end=1441
print('BUILT',len(statics),'visual objects,',len(colliders),'static collision boxes;',len(loose),'falling books;',len(recepts),'receptacles',flush=True)
# Save spawn transform provenance before stepping.
spawn=[{'id':catalog[i]['id'],'title':catalog[i]['title'],'location_metres':list(o.location),'rotation_euler_blender':list(o.rotation_euler),'scale_blender':list(o.scale)} for i,o in enumerate(loose)]
(ROOT/'spawn_provenance.json').write_text(json.dumps(spawn,indent=2))
# Simulate sixty seconds. The last six are an extra settling hold.
start=time.time();sample={}
for frame in range(1,1442):
 scene.frame_set(frame)
 if frame in [241,1297,1441]:sample[frame]=[list(o.matrix_world.translation) for o in loose]
 if frame%48==1:print('SIM',frame,'/',1441,'elapsed',round(time.time()-start,1),flush=True)
# Bake final matrices into transforms, then remove active bodies to keep a stable authored scene.
final_matrices=[o.matrix_world.copy() for o in loose]
for o,m in zip(loose,final_matrices):
 bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.rigidbody.object_remove();o.select_set(False);o.matrix_world=m
scene.frame_set(1);bpy.context.view_layer.update()
# Remove hidden Bullet proxy geometry after saving colliders.
for o in list(bpy.data.objects):
 if o.name.startswith('PHYS_'):bpy.data.objects.remove(o,do_unlink=True)
# Origins remain at book centres. Convert the full orientation to Fio's Ry Rx Rz convention.
def fio_rot(matrix):
 r=C@matrix.to_quaternion().to_matrix()@C.transposed();p=math.asin(max(-1,min(1,-r[1][2])))
 if abs(r[1][2])>.999999:y=math.atan2(-r[2][0],r[0][0]);z=0
 else:y=math.atan2(r[0][2],r[2][2]);z=math.atan2(r[1][0],r[1][1])
 return [math.degrees(v) for v in (p,y,z)]
settled=[]
for i,o in enumerate(loose):
 sc=o.scale;pos=o.location;r=fio_rot(o.matrix_world);corners=[o.matrix_world@Vector(v) for v in o.bound_box]
 bounds=[max(v[j] for v in corners)-min(v[j] for v in corners) for j in range(3)]
 settled.append({'id':catalog[i]['id'],'title':catalog[i]['title'],'author':catalog[i]['author'],'pos':[pos.x*S,pos.z*S,-pos.y*S],'rotation':r,'scale':[sc.x,sc.z,sc.y],'collision_size':[bounds[0]*S,bounds[2]*S,bounds[1]*S]})
(ROOT/'settled_books.json').write_text(json.dumps(settled,indent=2))
(ROOT/'geometry.json').write_text(json.dumps({'colliders':colliders,'receptacles':recepts,'lights':lights,'used_book_indices':sorted(used)},indent=2))
displacements=[math.dist(a,b) for a,b in zip(sample[1297],sample[1441])]
report={'engine':'Blender 4.3.2 / Bullet rigid body','seed':20261024,'books':384,'gravity_m_s2':9.81,'spawn_height_metres':[min(p[2] for p in initial),max(p[2] for p in initial)],'simulation_seconds':60,'settling_hold_seconds':6,'fps':24,'substeps_per_frame':8,'solver_iterations':35,'max_translation_during_last_6s_m':max(displacements),'moving_more_than_1cm_last_6s':sum(v>.01 for v in displacements),'minimum_book_centre_height_m':min(o.location.z for o in loose),'receptacle_capacity':sum(r['capacity'] for r in recepts)}
(ROOT/'PHYSICS_REPORT.json').write_text(json.dumps(report,indent=2));print('SETTLED',report,flush=True)
# Robust self-contained Wavefront exporter with Y-up vertices and relative MTL textures.
def export_obj(path,objects,world=True):
 deps=bpy.context.evaluated_depsgraph_get();materials={};vo=0;to=0;no=0;triangles=0
 with path.open('w') as f:
  f.write('# Lantern House Library | Fio Y-up, 50 units per metre\n# fio:up=y\nmtllib '+path.with_suffix('.mtl').name+'\n')
  for o in objects:
   if o.type!='MESH' or o.hide_render:continue
   ev=o.evaluated_get(deps);me=ev.to_mesh();me.calc_loop_triangles();matr=o.matrix_world if world else Matrix.Identity(4);normal=matr.to_3x3().inverted().transposed();uv=me.uv_layers.active
   f.write('o '+o.name.replace(' ','_').replace('#','')+'\n')
   for v in me.vertices:
    p=matr@v.co;f.write('v %.5f %.5f %.5f\n'%(p.x*S,p.z*S,-p.y*S))
   for lp in me.loops:
    q=uv.data[lp.index].uv if uv else (.5,.5);f.write('vt %.6f %.6f\n'%(q[0],q[1]));n=normal@lp.normal;n.normalize();f.write('vn %.6f %.6f %.6f\n'%(n.x,n.z,-n.y))
   current=None
   for t in me.loop_triangles:
    mi=t.material_index;m=me.materials[mi] if mi<len(me.materials) else wood;mn=m.name.replace(' ','_');materials[mn]=m
    if mn!=current:f.write('usemtl '+mn+'\n');current=mn
    refs=['%d/%d/%d'%(vo+vi+1,to+li+1,no+li+1) for vi,li in zip(t.vertices,t.loops)];f.write('f '+' '.join(refs)+'\n');triangles+=1
   vo+=len(me.vertices);to+=len(me.loops);no+=len(me.loops);ev.to_mesh_clear()
 with path.with_suffix('.mtl').open('w') as f:
  for name,m in materials.items():
   color=m.diffuse_color;f.write('newmtl '+name+'\nKa 0.2 0.2 0.2\nKd %.5f %.5f %.5f\nKs 0.12 0.12 0.12\nNs 28\nd 1\n'%tuple(color[:3]))
   for node in m.node_tree.nodes:
    if node.type=='TEX_IMAGE' and node.image:
     texpath=Path(bpy.path.abspath(node.image.filepath));f.write('map_Kd '+os.path.relpath(texpath,path.parent).replace('\\','/')+'\n');break
   if m.name in ['Frosted_amber','Moonlit_window']:f.write('Ke %.4f %.4f %.4f\n'%tuple(color[:3]))
   f.write('\n')
 print('EXPORTED',path.name,vo,'verts',triangles,'triangles',flush=True)
export_obj(MOD/'lantern_house_room.obj',statics)
# Master book is unscaled and unrotated, all dimensions and title art preserved by per-Prop properties.
temp=bpy.data.objects.new('Book_master',base);bpy.context.collection.objects.link(temp);export_obj(MOD/'lantern_book.obj',[temp],False);bpy.data.objects.remove(temp,do_unlink=True)
export_obj(ROOT/'Lantern_House_COMPLETE.obj',statics+loose)
# Camera: actual final geometry, no illustration or mockup.
def camera(name,loc,target,lens):
 data=bpy.data.cameras.new(name);o=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(o);o.location=loc;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();data.lens=lens;return o
cam=camera('Hero_view',(0,-10.1,3.3),(0,3.4,1.55),21);scene.camera=cam
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'Lantern_House.blend'))
scene.render.filepath=str(ROOT/'preview_interior.png');bpy.ops.render.render(write_still=True)
scene.camera=camera('Book_detail',(-1.2,-6.5,1.55),(0,-4.7,.03),43);scene.render.filepath=str(ROOT/'preview_books.png');bpy.ops.render.render(write_still=True)
print('ALL_DONE',flush=True)
