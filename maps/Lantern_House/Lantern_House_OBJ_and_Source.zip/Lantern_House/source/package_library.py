import os,sys,json,uuid,math,csv,shutil,zipfile,hashlib
from pathlib import Path
os.environ['QT_QPA_PLATFORM']='offscreen'
sys.path.insert(0,'/workspace/Fio')
from PyQt5.QtWidgets import QApplication
app=QApplication([])
from plugins.manager import load_plugins,get_manager
load_plugins()
from engine.prop_entity import Prop
from editor.things import PlayerStart,Light,Thing
from plugins.tidy.entities import TidyReceptacle,TidyGoal
from editor.package_exporter import PackageExporter
ROOT=Path('/workspace/work/library');OUT=Path('/workspace/output');OUT.mkdir(exist_ok=True)
books=json.loads((ROOT/'settled_books_final.json').read_text());geo=json.loads((ROOT/'geometry.json').read_text())
S=50
def fio(p):return [float(p[0]*S),float(p[2]*S),float(-p[1]*S)]
def ident(s):return str(uuid.uuid5(uuid.NAMESPACE_URL,'lantern-house/'+s))
brushes=[]
for i,co in enumerate(geo['colliders']):
 size=co['size'];brushes.append({'pos':fio(co['pos']),'size':[max(.1,size[0]*S-.15),max(.1,size[2]*S-.15),max(.1,size[1]*S-.15)],'textures':{k:'nodraw.jpg' for k in ['north','south','east','west','top','down']},'is_trigger':False,'id':ident('brush'+str(i))})
things=[]
room=Prop(pos=[0,0,0],properties={'name':'Lantern House - detailed library','id':ident('architecture'),'render_mode':'model','model_path':'assets/models/lantern_house_room.obj','no_collision':True,'physics_enabled':False,'scale':[1,1,1],'rotation':[0,0,0]});things.append(room)
for b in books:
 props={'name':b['title'],'id':ident(b['id']),'render_mode':'model','model_path':b['model_path'],'texture':'assets/textures/books/'+b['id']+'.png','rotation':[0,0,0],'scale':[1,1,1],'tidy_category':'book','carry_enabled':True,'carry_reach':135.0,'carry_distance':55.0,'carry_offset':[0,-8,0],'drop_velocity':0.0,'drop_angular_velocity':[0,0,0],'physics_enabled':True,'gravity':True,'no_collision':False,'collision_shape':'mesh','collision_size':[0,0,0],'mass':.85,'friction':.66,'linear_damping':.36,'angular_damping':.48,'collect_enabled':False,'book_id':b['id'],'title':b['title'],'author':b['author']}
 things.append(Prop(pos=b['pos'],properties=props))
# The shared slot origin is the shelf top. Book meshes have their own origins
# at their lowest points, so arbitrary settled orientations remain supported.
for i,r in enumerate(geo['receptacles']):
 pos=fio(r['pos']);pos[1]-=17.25 # .35m raised placement anchor -> .005m above the shelf
 things.append(TidyReceptacle(pos=pos,properties={'name':r['name'],'id':ident(r['name']),'accepts':'book','capacity':r['capacity'],'slot_cols':r['slot_cols'],'slot_spacing':[x*S for x in r['slot_spacing']],'slot_offset':[x*S for x in r['slot_offset']],'reach':185.0,'disabled':False}))
player=PlayerStart(pos=[0,8,510],properties={'name':'Library entrance','id':ident('player'),'angle':180.0,'primary':True});things.append(player)
for i,(loc,col,power,size) in enumerate(geo['lights']):
 things.append(Light(pos=fio(loc),properties={'name':'Warm reading light '+str(i+1),'id':ident('light'+str(i)),'colour':[int(c*255) for c in col],'intensity':1.35,'radius':680,'state':'on','casts_shadows':False}))
# Completion is visible in the native Tidy HUD and switches on a green lamp.
completion=Light(pos=[0,192,485],properties={'name':'All books returned','id':ident('complete'),'colour':[100,255,150],'intensity':2.8,'radius':320,'state':'off','casts_shadows':False});things.append(completion)
goal=TidyGoal(pos=[0,60,480],properties={'name':'Put away all 384 books','id':ident('goal'),'target':'all','category':'book','show_hud':True});goal.add_output_connection('OnComplete','All books returned','TurnOn',target_id=completion.properties['id']);things.append(goal)
for thing in things:
 if thing.properties.get('render_mode')=='model':thing.properties['sprite_path']=''
doc={'version':3,'brushes':brushes,'things':[t.to_dict() for t in things]}
(ROOT/'maps/Lantern_House.json').write_text(json.dumps(doc,indent=1))
metadata={'title':'Lantern House - The Great Book Tidy','author':'Created for you with Codex','description':'A richly detailed walnut library. Return all 384 uniquely titled physics books to 408 shelf slots. Chaos was settled using a 60-second Bullet gravity simulation, including a 6-second settling hold. Requires installed Tidy 2.0 plugin.','version':'1.0.0','map_path':'maps/Lantern_House.json','plugins':['tidy'],'format_version':1}
(ROOT/'metadata.json').write_text(json.dumps(metadata,indent=2))
exporter=PackageExporter(None,str(ROOT));ok,errors=exporter.export(str(OUT/'Lantern_House.fiopak'),metadata,str(ROOT/'maps/Lantern_House.json'))
assert ok, errors
assert not errors,errors
# Copy the complete OBJ snapshot into assets/models for sane relative texture paths.
shutil.copy2(ROOT/'Lantern_House_COMPLETE.obj',ROOT/'assets/models/Lantern_House_COMPLETE.obj')
shutil.copy2(ROOT/'Lantern_House_COMPLETE.mtl',ROOT/'assets/models/Lantern_House_COMPLETE.mtl')
# Snapshot MTL was exported from project root and must be relative to assets/models.
p=ROOT/'assets/models/Lantern_House_COMPLETE.mtl';p.write_text(p.read_text().replace('map_Kd assets/textures/','map_Kd ../textures/'))
readme='''# Lantern House - The Great Book Tidy

In Fio choose **Tools > Play Game Package...** and select `Lantern_House.fiopak`. For editing, unpack the source bundle into a Fio project and open `maps/Lantern_House.json`, then press Play. Use a current Fio build with the **Tidy 2.0 plugin installed** (the workspace build includes it). Tidy is automatically activated by this map. A .fiopak contains world data and assets; Fio requires plugins to be installed separately and rejects bundled plugin code.

Move with WASD, look with the mouse. Look down at a loose book and press **E** to carry it. Approach any empty lower shelf, aim at the small brass shelf markers, and press **E** to put it away. The Tidy HUD counts all **384** books. All books fit in **408** return slots. A green light at the entrance switches on when the goal is complete.

The 18 tall cases have four lower return shelves each and two upper collection shelves. Four double-sided islands provide four return shelves per side. Upper collection volumes are fixed room detail and do not count toward the task. Every visible book has a distinct title; the catalogue lists every volume actually present. Collection shelves have individually mapped title/spine art in a shared atlas.

The floor mess is a real **Blender/Bullet rigid-body result**. The 384 books were spawned 4.75-5.90 m above the floor with random orientations and varied dimensions, then dropped under 9.81 m/s² gravity for 60 seconds, including six final seconds of settling. `PHYSICS_REPORT.json` and `spawn_provenance.json` record the run. This drop was simulated in Blender rather than Fio's editor. The result was then simulated in Fio for 12 seconds. No book moved during the final six seconds of the native Fio run. Those final positions and shapes are saved in the native Fio map. In Fio they remain separate carryable, solid, gravity-enabled core Props.

Each loose book has an individually exported mesh with its settled orientation baked in and its origin at its lowest point. This allows Tidy's position-only snap to place the actual book on a shelf surface without floating or intersecting the shelf. Each Prop retains normal Fio carrying and dropping. The native engine uses its supported bounds-based dynamic collisions during play, so later interactions can differ from the original Bullet simulation.

## Editable files

- `maps/Lantern_House.json` - playable native Fio map.
- `assets/models/lantern_house_room.obj` - static room with carved shelves and the fixed collection.
- `assets/models/B0001.obj` through `B0384.obj` - the individual interactive books, MTLs and cover textures.
- `assets/models/lantern_book.obj` - unrotated reusable master book.
- `assets/models/Lantern_House_COMPLETE.obj` - full, settled visual snapshot with separate named book objects. Import this for modelling/reference; use the native JSON map or .fiopak for physics and Tidy gameplay.
- `Lantern_House.blend` - editable source scene with the settled objects and cameras.
- `BOOK_CATALOGUE.csv` - every unique printed title, author, year and collection ID.
- `source/` - reproducible generation and packaging scripts. They expect Blender 4.3+ and a Fio checkout; adjust ROOT paths for your machine.

All OBJ exports explicitly declare Fio Y-up. Scale is 50 Fio units per metre. Keep OBJ/MTL files together and preserve relative `../textures/` paths. For an unpacked native map, copy the `assets` and `maps` trees into your Fio project root, preserving the directory structure. NODRAW brush volumes provide static collision; these are editor aids and are hidden in Play mode. The detailed room OBJ supplies the visible geometry.

All geometry, title designs and procedural textures were made for this map. You may edit, use and redistribute these map assets for any purpose (CC0). Fio and the Tidy plugin remain governed by their own licenses. The preview images render the actual finished geometry in Blender; Fio's lighting will differ.
'''
(ROOT/'README.md').write_text(readme)
source=ROOT/'source';source.mkdir(exist_ok=True)
for name in ['create_textures.py','build_library.py','finalize_geometry.py','settle_fio.py','sync_and_render.py','package_library.py']:shutil.copy2(Path('/workspace/work')/name,source/name)
for name in ['README.md','BOOK_CATALOGUE.csv','PHYSICS_REPORT.json','preview_interior.png','preview_books.png','preview_overview.png']:
 if (ROOT/name).exists():shutil.copy2(ROOT/name,OUT/name)
# Useful native source bundle; includes OBJ/MTL/PNG and the .blend, no unrelated engine files.
with zipfile.ZipFile(OUT/'Lantern_House_OBJ_and_Source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(ROOT.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(ROOT).as_posix()
  if rel in ['Lantern_House_COMPLETE.obj','Lantern_House_COMPLETE.mtl','book_catalogue.json','settled_books.json','settled_books_final.json','geometry.json'] or rel.endswith('.blend1'):continue
  z.write(p,'Lantern_House/'+rel)
print('PACKAGED',len(brushes),'brushes',len(things),'things; capacity',sum(r['capacity'] for r in geo['receptacles']),flush=True)
print('Exporter errors:',errors,flush=True)
