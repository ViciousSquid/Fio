from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import random,math,json,csv
ROOT=Path('/workspace/work/library'); TEX=ROOT/'assets/textures'; random.seed(49173)
F='/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf'; B='/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf'
PALETTES=[('#253f43','#cfb773'),('#683038','#e8ca8b'),('#263b59','#d5c9a4'),('#3f503c','#d4c391'),('#774b31','#e3c6a3'),('#443651','#d9c3ae'),('#a16d36','#312a26'),('#354f63','#d3d7c7'),('#493e35','#cab590'),('#844b4e','#eed8c5'),('#2f5955','#c9cf9e'),('#bab08d','#49473b')]
adjs=['Amber','Forgotten','Silent','Midnight','Hidden','Silver','Wandering','Last','Verdant','Winter','Distant','Velvet','Hollow','Golden','Secret','Infinite','Glass','Ivory','Crimson','Unwritten','Fallen','Autumn','Celestial','Borrowed','Patient','Lost','Blue','Paper','Uncharted','Sleeping','Luminous','Copper','Tidal','Northern','Small','Wild','Ancient','Evanescent','Botanical','Clockwork']
nouns=['Atlas','Garden','Observatory','Orchard','Library','Voyage','Archive','Cartographer','Almanac','Labyrinth','Herbarium','Constellation','Tide','Manuscript','Cabinet','Chronicle','Lantern','Bestiary','Horizon','Symphony','Valley','Compass','Aquarium','Expedition','House','River','Museum','Equation','Moon','Letters','Theatre','Coast','Machine','Forest','Birdsong','Fable','Terrarium','Weather','Elegy','Sanctuary']
combos=[f'The {a} {n}' for a in adjs for n in nouns]; random.shuffle(combos)
first=['Ada','Elias','Mira','Jules','Clara','Theo','Iris','Felix','Nora','Edwin','Lena','Arthur','Sylvie','Rowan','Mae','Otto','Vera','Cecil','Esme','Hugo','Alma','Basil','Cora','Leon']
last=['Vale','Marlowe','Finch','Ashford','Mercer','Hawthorn','Sable','Whitmore','Reed','Alder','Thorne','Hale','Wren','Linden','North','Bell','Hart','Quill','Rowe','Fox','Moss','Wood','Shaw','Stone']
books=[]
for i in range(1400):
 books.append({'id':f'B{i+1:04d}','title':combos[i],'author':first[i%24]+' '+last[(i//24)%24], 'year':1860+i%165,'kind':'tidy physics prop' if i<384 else 'shelf collection'})

def cover(info,size=512):
 rng=random.Random(info['id']); bg,ink=PALETTES[(int(info['id'][1:])*7)%len(PALETTES)]
 im=Image.new('RGB',(512,512),bg); d=ImageDraw.Draw(im)
 # cover panel, separate spine and cream leaf edge
 d.rectangle((0,0,347,511),fill=bg); d.rectangle((353,0,423,511),fill=bg); d.rectangle((436,0,511,511),fill='#e3dac0')
 for _ in range(2200):
  x=rng.randrange(347);y=rng.randrange(512)
  d.point((x,y),fill=tuple(max(0,min(255,c+rng.choice([-5,4]))) for c in Image.new('RGB',(1,1),bg).getpixel((0,0))))
 for x in [12,20]: d.rectangle((x,x,346-x,511-x),outline=ink,width=2 if x==12 else 1)
 for y in range(4,512,4): d.line((438,y,510,y),fill=(200+rng.randrange(18),191+rng.randrange(15),166+rng.randrange(18)),width=1)
 # spine bands and vertical readable title
 for y in [28,40,442,454]: d.line((357,y,420,y),fill=ink,width=3)
 spine=Image.new('RGB',(380,56),bg); ds=ImageDraw.Draw(spine)
 font=ImageFont.truetype(B,19)
 while ds.textlength(info['title'],font=font)>365: font=ImageFont.truetype(B,font.size-1)
 ds.text((190,29),info['title'],font=font,fill=ink,anchor='mm')
 spine=spine.rotate(90,expand=True);im.paste(spine,(360,66))
 d=ImageDraw.Draw(im)
 title=info['title'].upper(); words=title.split(); lines=[];line=''
 ft=ImageFont.truetype(B,27)
 for word in words:
  trial=(line+' '+word).strip()
  if d.textlength(trial,font=ft)>286: lines.append(line);line=word
  else:line=trial
 lines.append(line)
 for j,l in enumerate(lines): d.text((173,100+j*37),l,font=ft,fill=ink,anchor='mm')
 d.text((173,53),'THE LANTERN COLLECTION',font=ImageFont.truetype(F,12),fill=ink,anchor='mm')
 # unique geometric gilded medallions
 cx,cy=173,293; rr=46
 d.ellipse((cx-rr,cy-rr,cx+rr,cy+rr),outline=ink,width=2)
 sides=3+int(info['id'][1:])%7;phase=rng.random()*math.pi
 pts=[(cx+36*math.cos(phase+j*2*math.pi/sides),cy+36*math.sin(phase+j*2*math.pi/sides)) for j in range(sides)]
 d.line(pts+[pts[0]],fill=ink,width=2)
 for x,y in pts:d.line((cx,cy,x,y),fill=ink,width=1)
 d.ellipse((cx-6,cy-6,cx+6,cy+6),fill=ink)
 d.text((173,391),info['author'].upper(),font=ImageFont.truetype(F,17),fill=ink,anchor='mm')
 d.text((173,435),str(info['year'])+'  /  '+info['id'],font=ImageFont.truetype(F,13),fill=ink,anchor='mm')
 d.text((173,471),'LANTERN HOUSE PRESS',font=ImageFont.truetype(F,10),fill=ink,anchor='mm')
 return im.resize((size,size),Image.Resampling.LANCZOS)
for info in books[:384]:cover(info).save(TEX/'books'/f'{info["id"]}.png',optimize=True)
# One atlas for uniquely titled, non-interactive collection volumes.
atlas=Image.new('RGB',(4096,4096));tile=128
for j,info in enumerate(books[384:]): atlas.paste(cover(info,128),((j%32)*128,(j//32)*128))
atlas.save(TEX/'collection_atlas.png',optimize=True)
(ROOT/'book_catalogue.json').write_text(json.dumps(books,indent=2))
with (ROOT/'BOOK_CATALOGUE.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=books[0].keys());w.writeheader();w.writerows(books)
# seamless-ish warm wood grain, designed original procedural textures
for name,col in [('walnut',(83,53,35)),('oak',(117,79,46)),('floor',(112,77,48))]:
 rng=random.Random(name);im=Image.new('RGB',(512,512),col);d=ImageDraw.Draw(im)
 for y in range(512):
  light=math.sin(y*.19)*4+math.sin(y*.047)*8
  d.line((0,y,511,y),fill=tuple(int(c+light) for c in col))
 for _ in range(1200):
  y=rng.randrange(512);x=rng.randrange(512);length=rng.randrange(20,240)
  cc=tuple(max(0,min(255,c+rng.randrange(-16,17))) for c in col)
  d.line([(x,y),(min(511,x+length),y+math.sin(x*.035)*2)],fill=cc,width=1)
 im.save(TEX/f'{name}.png')
# painted plaques
labels=['LANTERN HOUSE','PUT AWAY EVERY BOOK','NATURAL HISTORY','VOYAGES & MAPS','FICTION & FABLES','SCIENCE & STARS','POETRY & LETTERS','THE READING ROOM','RETURNS  /  PRESS E','384 VOLUMES TO RETURN','A QUIET PLACE FOR CURIOUS MINDS']
for i,text in enumerate(labels):
 im=Image.new('RGB',(1024,192),'#273e3a');d=ImageDraw.Draw(im);d.rectangle((8,8,1015,183),outline='#cbb477',width=3)
 font=ImageFont.truetype(B,52)
 while d.textlength(text,font=font)>960:font=ImageFont.truetype(B,font.size-1)
 d.text((512,96),text,font=font,fill='#e5d6aa',anchor='mm');im.save(TEX/f'plaque_{i:02d}.png')
Image.new('RGB',(8,8),(255,0,255)).save(TEX/'nodraw.jpg')
print('Textures and 1400 unique catalogue titles generated',flush=True)
