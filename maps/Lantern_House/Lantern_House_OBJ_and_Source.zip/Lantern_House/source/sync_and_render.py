import bpy,json,math,ast,os
from pathlib import Path
from mathutils import Vector,Matrix
ROOT=Path('/workspace/work/library');MOD=ROOT/'assets/models';S=50;s=bpy.context.scene
corrections=json.loads((ROOT/'fio_settle_deltas.json').read_text());loose=[]
for o in s.objects:
 if o.type=='MESH' and '__' in o.name and o.name.split('__')[0] in corrections:
  if not o.get('fio_correction_applied',False):
   d=corrections[o.name.split('__')[0]];o.location+=Vector((d[0]/50,-d[2]/50,d[1]/50));o['fio_correction_applied']=True
  loose.append(o)
bpy.context.view_layer.update()
source=Path('/workspace/work/build_library.py').read_text();tree=ast.parse(source);func=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='export_obj');exec(compile(ast.Module(body=[func],type_ignores=[]),'<export_obj>','exec'))
wood=bpy.data.materials['Carved_walnut'];statics=[o for o in s.objects if o.type=='MESH' and o not in loose]
export_obj(ROOT/'Lantern_House_COMPLETE.obj',statics+loose)
# Elevated wide view shows the complete room and the book-filled aisles.
cam=s.camera;cam.location=(0,-10.7,6.0);cam.rotation_euler=(Vector((0,1.4,1.3))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.lens=16
s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=32;s.render.resolution_x=1600;s.render.resolution_y=1100;s.render.resolution_percentage=100
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'Lantern_House.blend'))
s.render.filepath=str(ROOT/'preview_interior.png');bpy.ops.render.render(write_still=True)
cam=bpy.data.objects.new('Book_detail',bpy.data.cameras.new('Book_detail'));s.collection.objects.link(cam);cam.location=(-1.2,-6.5,1.55);cam.rotation_euler=(Vector((0,-4.7,.03))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.lens=43;s.camera=cam
s.render.resolution_x=1200;s.render.resolution_y=800;s.render.filepath=str(ROOT/'preview_books.png');bpy.ops.render.render(write_still=True)
print('FINAL_PREVIEWS_READY',flush=True)
