import os,sys,json,math
from pathlib import Path
os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['SDL_AUDIODRIVER']='dummy';sys.path.insert(0,'/workspace/Fio')
from PyQt5.QtWidgets import QApplication
app=QApplication([])
from plugins.manager import load_plugins
load_plugins()
from editor.editor_state import EditorState
from engine.logic_thread import LogicThread
from engine.threaded_game_state import ThreadedGameState
R=Path('/workspace/work/library');os.chdir(R);doc=json.loads((R/'maps/Lantern_House.json').read_text());state=EditorState();state.load_from_data(doc,save_undo=False);logic=LogicThread(ThreadedGameState(),state)
props=[t for t in state.things if t.properties.get('tidy_category')=='book'];before={p.properties['book_id']:list(p.pos) for p in props}
try:
 logic.session_runtime.apply_play_mode(True);world=logic.session_runtime.physics_world
 prev=[list(p.pos) for p in props];stable=None
 for block in range(1,13):
  for _ in range(360):world.step(1/60,None)
  move=max(math.dist(a,p.pos) for a,p in zip(prev,props));print('FIO SETTLE',block*6,'seconds; max last 6 sec',move,'units',flush=True)
  prev=[list(p.pos) for p in props]
  if block>=2 and move<.001:stable=block*6;break
 assert stable is not None,'Fio physics did not reach a stable snapshot'
 after={p.properties['book_id']:list(p.pos) for p in props}
 for t in doc['things']:
  if t['properties'].get('book_id') in after:t['pos']=after[t['properties']['book_id']]
 (R/'maps/Lantern_House.json').write_text(json.dumps(doc,indent=1))
 books=json.loads((R/'settled_books_final.json').read_text())
 for b in books:b['pos']=after[b['id']]
 (R/'settled_books_final.json').write_text(json.dumps(books,indent=2))
 deltas={i:[after[i][j]-before[i][j] for j in range(3)] for i in before};(R/'fio_settle_deltas.json').write_text(json.dumps(deltas,indent=2))
 report=json.loads((R/'PHYSICS_REPORT.json').read_text());report['fio_followup_simulation_seconds']=stable;report['fio_final_6s_max_translation_units']=move;report['fio_max_correction_units']=max(math.dist(before[i],after[i]) for i in before);report['fio_physics_body_count']=len(world.bodies);(R/'PHYSICS_REPORT.json').write_text(json.dumps(report,indent=2));print('FIO SNAPSHOT SAVED',flush=True)
finally:logic.session_runtime.apply_play_mode(False);logic.stop()
