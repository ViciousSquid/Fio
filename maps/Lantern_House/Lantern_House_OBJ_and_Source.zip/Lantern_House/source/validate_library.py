import os,sys,json,math,csv,zipfile,time
from pathlib import Path
os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['SDL_AUDIODRIVER']='dummy'
sys.path.insert(0,'/workspace/Fio')
from PyQt5.QtWidgets import QApplication
app=QApplication([])
from plugins.manager import load_plugins,get_manager
load_plugins()
from editor.editor_state import EditorState
from engine.obj_loader import OBJLoader
from player.fiopak import FioPackage
from engine.logic_thread import LogicThread
from engine.threaded_game_state import ThreadedGameState
import glm
ROOT=Path('/workspace/work/library');OUT=Path('/workspace/output');os.chdir(ROOT)
report={};doc=json.loads((ROOT/'maps/Lantern_House.json').read_text());state=EditorState();state.load_from_data(doc,save_undo=False)
props=[t for t in state.things if t.properties.get('tidy_category')=='book'];recepts=[t for t in state.things if t.properties.get('type')=='tidyreceptacle'];goals=[t for t in state.things if t.properties.get('type')=='tidygoal']
assert len(props)==384;assert len({p.properties['title'] for p in props})==384;assert len({p.properties['model_path'] for p in props})==384
assert sum(r.properties['capacity'] for r in recepts)==408
assert len(goals)==1 and goals[0].target_count(384)==384
assert not any(t.__class__.__name__=='UnresolvedThing' for t in state.things)
report.update(native_editor_load=True,tidy_objects=len(props),receptacles=len(recepts),slot_capacity=408,unresolved_entities=0)
print('Native map schema / plugin activation verified',flush=True)
# All 384 title textures and individually bounded models load through the real Fio parser.
for p in props:
 model=OBJLoader();assert model.load(p.properties['model_path']);assert model.up_axis=='y';assert len(model.vertices)==32;assert len(model.faces)==48
 assert abs(min(v[1] for v in model.vertices))<1e-5
 assert all(v[0]>=0 and v[1]>=0 for face in model.faces for v in face['vertices'])
 assert len(model.materials)>0
 for m in model.materials.values():
  if m.get('texture'):assert (Path(m['mtl_dir'])/m['texture']).is_file(),m
 assert Path(p.properties['texture']).is_file()
room=OBJLoader();assert room.load('assets/models/lantern_house_room.obj');assert room.up_axis=='y';report.update(obj_parser_load=True,room_vertices=len(room.vertices),room_triangles=len(room.faces))
print('All OBJ / MTL / texture links verified; room',len(room.faces),'triangles',flush=True)
# Archive structural check and portable path resolution.
pakpath=OUT/'Lantern_House.fiopak'
if pakpath.exists() and '--skip-archive' not in sys.argv:
 with FioPackage.open(str(pakpath)) as pak:
  assert pak.required_plugins==['tidy'];assert pak.start_map_path()=='maps/Lantern_House.json';assert pak.load_start_map()==doc
  refs=[p.properties['model_path'] for p in props]+[p.properties['texture'] for p in props]+['assets/models/lantern_house_room.obj','nodraw.jpg']
  assert all(pak.has_asset(r) for r in refs)
  assert not any(n.startswith('plugins/') for n in pak.namelist())
  with zipfile.ZipFile(pakpath) as z:assert z.testzip() is None
  report.update(fiopak_reader_load=True,archive_entries=len(pak.namelist()),zip_crc_valid=True)
logic=LogicThread(ThreadedGameState(),state)
try:
 logic.session_runtime.apply_play_mode(True)
 tidyplug=next(p for p in get_manager().plugins if p.name=='tidy');tidy=tidyplug._sessions.get(logic)
 assert tidy is not None and tidy.total==384
 world=logic.session_runtime.physics_world
 assert len(world.bodies)==384
 before=[list(p.pos) for p in props]
 for _ in range(360):world.step(1/60,None)
 max_move=max(math.dist(a,p.pos) for a,p in zip(before,props));assert max_move<.01,max_move
 report.update(core_physics_bodies=384,initial_6s_max_movement_fio_units=max_move)
 # Pick a book using the production carry ray, then aim at a real shelf and place with E.
 p=min(props,key=lambda p:abs(p.pos[0])+abs(p.pos[2]-100))
 from engine.player import Player
 if logic.player_runtime.player is None:logic.player_runtime.player=Player(0.0,0.0)
 player=logic.player_runtime.player;player.pos=glm.vec3(p.pos[0],0,p.pos[2]-55);player.angle=0;player.pitch=math.atan2(p.pos[1]+1-player.camera_height,55)
 core=logic.prop_runtime;core.tick(.016,use_pressed=True);assert core.held is not None,'carry E did not pick a book'
 held=core.held;r=recepts[0]
 player.pos=glm.vec3(r.pos[0],0,r.pos[2]+85);player.angle=math.pi;player.pitch=math.atan2(r.pos[1]-player.camera_height,85)
 core.tick(.016,use_pressed=True);assert core.held is None;assert tidy.tidied==1
 report.update(native_E_carry_and_shelf_place=True)
 # Exercise every remaining slot through the real Tidy placement implementation.
 fired=[];orig=logic.io_manager.fire_output
 def record(entity,output,value=None):
  if output=='OnComplete':fired.append(entity.properties['id'])
  return orig(entity,output,value)
 logic.io_manager.fire_output=record
 remaining=[p for p in props if id(p) not in tidy._tidied_ids]
 for p in remaining:
  r=next(r for r in recepts if tidy._fill_count(r)<r.properties['capacity'])
  tidy._place(p,r)
 assert tidy.tidied==384 and len(tidy._tidied_ids)==384
 assert len(fired)==1
 assert all(not p.properties['carry_enabled'] for p in props)
 logic.io_manager.update(.1)
 completion=next(t for t in state.things if t.properties.get('name')=='All books returned')
 assert completion.properties['state']=='on',completion.properties
 report.update(full_goal_completion=True,completion_output_fires=1,completion_light_turns_on=True)
finally:
 logic.session_runtime.apply_play_mode(False);logic.stop()
report['unique_titled_volumes_total']=sum(1 for _ in csv.DictReader((ROOT/'BOOK_CATALOGUE.csv').open()))
report['physics_simulation']=json.loads((ROOT/'PHYSICS_REPORT.json').read_text())
(OUT/'VALIDATION_REPORT.json').write_text(json.dumps(report,indent=2));print('VALIDATION PASSED',json.dumps(report,indent=2),flush=True)
