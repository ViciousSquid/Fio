# Run inside Blender against the settled .blend after the simulation build.
import bpy,json,math,os
from pathlib import Path
from mathutils import Matrix,Vector
ROOT=Path('/workspace/work/library'); MOD=ROOT/'assets/models';S=50
scene=bpy.context.scene
scene.cycles.use_denoising=False;scene.cycles.samples=96
# Correct the upper collection spines to stand upright with the title faces out.
for o in bpy.data.objects:
 if o.type=='MESH' and o.data.name.startswith('Collection_') and abs(o.rotation_euler.y)>1:
  angle=o.rotation_euler.z;o.rotation_euler=(math.pi/2,0,angle+math.pi/2)
bpy.context.view_layer.update()
# Re-run the recorded drop on an isolated lightweight Bullet scene, allowing
# a full minute for thin books and stacks to reach rest.
main_scene=scene;original_scene=scene
sim=bpy.data.scenes.new('Deterministic_Bullet_drop');bpy.context.window.scene=sim
spawn=json.loads((ROOT/'spawn_provenance.json').read_text());geo=json.loads((ROOT/'geometry.json').read_text())
unit=bpy.data.meshes.new('Collision_cuboid');unit.from_pydata([(-.5,-.5,-.5),(.5,-.5,-.5),(.5,.5,-.5),(-.5,.5,-.5),(-.5,-.5,.5),(.5,-.5,.5),(.5,.5,.5),(-.5,.5,.5)],[],[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)])
passive=[]
for co in geo['colliders']:
 o=bpy.data.objects.new('Proxy',unit);sim.collection.objects.link(o);o.location=co['pos'];o.scale=co['size'];passive.append(o);o.select_set(True)
bpy.context.view_layer.objects.active=passive[0];bpy.ops.rigidbody.objects_add(type='PASSIVE')
for o in passive:o.rigid_body.collision_shape='BOX';o.rigid_body.friction=.68;o.rigid_body.use_margin=True;o.rigid_body.collision_margin=.001;o.select_set(False)
falling=[]
for rec in spawn:
 src=next(o for o in main_scene.objects if o.name.startswith(rec['id']+'__'))
 o=bpy.data.objects.new(rec['id'],src.data);sim.collection.objects.link(o);o.location=rec['location_metres'];o.rotation_euler=rec['rotation_euler_blender'];o.scale=rec['scale_blender'];falling.append(o);o.select_set(True)
bpy.context.view_layer.objects.active=falling[0];bpy.ops.rigidbody.objects_add(type='ACTIVE')
for o in falling:
 r=o.rigid_body;r.collision_shape='CONVEX_HULL';r.mass=.5+o.scale.z*.35;r.friction=.66;r.restitution=.075;r.linear_damping=.36;r.angular_damping=.48;r.use_deactivation=True;r.use_start_deactivated=False;r.deactivate_linear_velocity=.10;r.deactivate_angular_velocity=.12;r.use_margin=True;r.collision_margin=.0015
sim.gravity=(0,0,-9.81);sim.render.fps=24;sim.frame_start=1;sim.frame_end=1441;sim.rigidbody_world.substeps_per_frame=8;sim.rigidbody_world.solver_iterations=35;sim.rigidbody_world.point_cache.frame_start=1;sim.rigidbody_world.point_cache.frame_end=1441
sample={}
for fr in range(1,1442):
 sim.frame_set(fr)
 if fr in [1297,1441]:sample[fr]=[list(o.matrix_world.translation) for o in falling]
 if fr%240==1:print('FINAL DROP',fr,'/ 1441',flush=True)
matrices=[o.matrix_world.copy() for o in falling]
bpy.context.window.scene=main_scene
for rec,m in zip(spawn,matrices):
 o=next(o for o in main_scene.objects if o.name.startswith(rec['id']+'__'));o.matrix_world=m
bpy.data.scenes.remove(sim);bpy.context.view_layer.update()
disp=[math.dist(a,b) for a,b in zip(sample[1297],sample[1441])]
report=json.loads((ROOT/'PHYSICS_REPORT.json').read_text());report.update(simulation_seconds=60,max_translation_during_last_6s_m=max(disp),moving_more_than_1cm_last_6s=sum(v>.01 for v in disp),minimum_book_centre_height_m=min(m.translation.z for m in matrices));(ROOT/'PHYSICS_REPORT.json').write_text(json.dumps(report,indent=2));print('FINAL REST',report,flush=True)
books=json.loads((ROOT/'settled_books.json').read_text())
# Bake each settled orientation/scale into its own mesh, with the origin at
# its lowest point. Tidy snaps positions only, so every book now rests on a
# shelf surface correctly while retaining its distinctive fallen shape.
for info in books:
 o=next(o for o in bpy.data.objects if o.name.startswith(info['id']+'__'))
 points=[o.matrix_world@v.co for v in o.data.vertices];origin=Vector((o.location.x,o.location.y,min(p.z for p in points)))
 material=o.data.materials[0];p=MOD/(info['id']+'.obj');matname='Cover_'+info['id']
 with p.open('w') as f:
  f.write('# Lantern House | Unique titled Tidy Prop\n# fio:up=y\nmtllib '+info['id']+'.mtl\no '+info['id']+'\n')
  for point in points:
   q=point-origin;f.write('v %.6f %.6f %.6f\n'%(q.x*S,q.z*S,-q.y*S))
  for loop in o.data.loops:
   uv=o.data.uv_layers.active.data[loop.index].uv;f.write('vt %.6f %.6f\n'%(uv.x,uv.y))
  f.write('usemtl '+matname+'\n')
  for poly in o.data.polygons:
   li=list(poly.loop_indices)
   for k in range(1,len(li)-1):
    tris=[li[0],li[k],li[k+1]];f.write('f '+' '.join('%d/%d'%(o.data.loops[j].vertex_index+1,j+1) for j in tris)+'\n')
 (p.with_suffix('.mtl')).write_text('newmtl '+matname+'\nKa 0.2 0.2 0.2\nKd 1 1 1\nKs 0.08 0.08 0.08\nNs 15\nd 1\nmap_Kd ../textures/books/'+info['id']+'.png\n')
 info['original_settled_rotation']=info['rotation'];info['original_settled_scale']=info['scale'];info['pos']=[origin.x*S,origin.z*S,-origin.y*S];info['rotation']=[0,0,0];info['scale']=[1,1,1];info['model_path']='assets/models/'+info['id']+'.obj'
(ROOT/'settled_books_final.json').write_text(json.dumps(books,indent=2))
# Reduce unused catalogue to volumes actually present in the final room.
cat=json.loads((ROOT/'book_catalogue.json').read_text());used=json.loads((ROOT/'geometry.json').read_text())['used_book_indices']
import csv
with (ROOT/'BOOK_CATALOGUE.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=cat[0].keys());w.writeheader();w.writerows(cat[j] for j in used)
print('Exported',len(books),'individual floor-aligned book Props; catalogue',len(used),flush=True)

# Re-export the corrected static scene and the full final snapshot.
import ast
source=Path('/workspace/work/build_library.py').read_text();tree=ast.parse(source)
func=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='export_obj')
exec(compile(ast.Module(body=[func],type_ignores=[]),'<export_obj>','exec'))
wood=bpy.data.materials['Carved_walnut']
loose=[o for o in scene.objects if o.type=='MESH' and any(o.name.startswith(i['id']+'__') for i in books)]
statics=[o for o in scene.objects if o.type=='MESH' and o not in loose and not o.name.startswith(('Proxy','B0'))]
export_obj(MOD/'lantern_house_room.obj',statics)
export_obj(ROOT/'Lantern_House_COMPLETE.obj',statics+loose)
# Refresh source with the genuinely final chaos and upright upper collection.
bpy.ops.file.pack_all()
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'Lantern_House.blend'))
scene.render.filepath=str(ROOT/'preview_interior.png');bpy.ops.render.render(write_still=True)
cam=bpy.data.objects.new('Book_detail_final',bpy.data.cameras.new('Book_detail_final'));scene.collection.objects.link(cam);cam.location=(-1.2,-6.5,1.55);cam.rotation_euler=(Vector((0,-4.7,.03))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.lens=43;scene.camera=cam
scene.render.filepath=str(ROOT/'preview_books.png');bpy.ops.render.render(write_still=True)
print('GEOMETRY_FINALIZED',flush=True)
